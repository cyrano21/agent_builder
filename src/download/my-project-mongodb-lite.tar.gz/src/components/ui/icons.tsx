import {
  Loader2,
  User,
  Github,
  Chrome,
} from "lucide-react"

export const Icons = {
  spinner: Loader2,
  user: User,
  gitHub: Github,
  google: Chrome,
}